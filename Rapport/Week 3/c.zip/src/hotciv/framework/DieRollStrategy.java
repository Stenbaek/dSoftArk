package hotciv.framework;

/**
 * Created by IntelliJ IDEA.
 * User: stenbaek
 * Date: 24/11/12
 * Time: 14.26
 * To change this template use File | Settings | File Templates.
 */
public interface DieRollStrategy {

    public int roll();

}
