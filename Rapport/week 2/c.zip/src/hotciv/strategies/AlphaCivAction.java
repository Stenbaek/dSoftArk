package hotciv.strategies;

import hotciv.framework.*;
import hotciv.standard.CityImpl;
import hotciv.standard.GameImpl;
import hotciv.standard.units.AbstractUnit;
import hotciv.standard.maps.UnitHashMap;
import hotciv.standard.units.Archer;

import java.util.Iterator;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: Thomas
 * Date: 20-11-12
 * Time: 09:41
 * To change this template use File | Settings | File Templates.
 */
public class AlphaCivAction implements CivActionStrategy {

    public void performUnitAction(Unit u, Position p, Game game) {} // does nothing

}
