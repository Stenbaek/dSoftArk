package hotciv.strategies;

import hotciv.framework.CivWinStrategy;
import hotciv.framework.Player;
import hotciv.standard.GameImpl;

/**
 * Created by IntelliJ IDEA.
 * User: stenbaek
 * Date: 22/11/12
 * Time: 23.08
 * To change this template use File | Settings | File Templates.
 */
public class EpsilonCivWin implements CivWinStrategy {
    @Override
    public Player getWinner(GameImpl game) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
