package hotciv.strategies;

import hotciv.framework.CivAttackStrategy;

/**
 * Created by IntelliJ IDEA.
 * User: stenbaek
 * Date: 22/11/12
 * Time: 23.10
 * To change this template use File | Settings | File Templates.
 */
public class EpsilonCivAttack implements CivAttackStrategy {
}
